import React from 'react'

const Loading=()=>{
return(
    <div><img src="images/laoding.gif" alt="Loading..."></img></div>
)
}
export default Loading;
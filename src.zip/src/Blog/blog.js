import React, { Component } from 'react'
class Blog extends Component {
    render() {
        return (
        <div>
            <h1>blog</h1>
            <img src={"/images/51262045_1103341223171975_1322785790169942848_n.jpg"} alt="" width="100%" height="100%"></img>
        </div>          
        )
    }
}

export default Blog;